# Octolearn
An android application created to learn new words in the form of flashcards.
